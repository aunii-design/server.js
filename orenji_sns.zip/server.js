const express = require('express');
const app = express();
const path = require('path');
const bodyParser = require('body-parser');

const posts = [];

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.post('/post', (req, res) => {
  const { username, password, content } = req.body;
  posts.push({ username, password, content, time: new Date() });
  res.redirect('/');
});

app.get('/posts', (req, res) => {
  res.json(posts);
});

app.listen(3000, () => {
  console.log('おれんじSNS が起動しました🍊 http://localhost:3000');
});
